Github Username: Linnnnng
Name: Lingjun Guan
Computing ID: lg3bv

Postive test cases:
dot.in
main.in
operator.in

Error test cases:
invalid_identifier.in
invalid_operator.in
invalid_symbol.in
